import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-produtos-salvos',
  templateUrl: './produtos-salvos.page.html',
  styleUrls: ['./produtos-salvos.page.scss'],
})
export class ProdutosSalvosPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
